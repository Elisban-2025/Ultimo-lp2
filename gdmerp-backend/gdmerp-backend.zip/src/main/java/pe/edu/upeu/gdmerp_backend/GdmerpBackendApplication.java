package pe.edu.upeu.gdmerp_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GdmerpBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GdmerpBackendApplication.class, args);
	}

}
